namespace Ecostar.MQConsumer.Core
{
    /// <summary>
    ///     MQ ��?�̮�?�̤��@����
    /// </summary>
    public partial class MQContext
    {
        /// <summary>
        /// mq�a�}
        /// </summary>
        public System.Uri MQUrl { get; set; }

    }
}