﻿using System.IO;

namespace DataOfScouts
{
    partial class DataOfScouts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        { 
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataOfScouts));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpAuthorization = new System.Windows.Forms.TabPage();
            this.gbAuthorization = new System.Windows.Forms.GroupBox();
            this.lbToken = new System.Windows.Forms.Label();
            this.lbAuthorization = new System.Windows.Forms.Label();
            this.tpAreas = new System.Windows.Forms.TabPage();
            this.dgvAreas = new System.Windows.Forms.DataGridView();
            this.tpCompetitions = new System.Windows.Forms.TabPage();
            this.tpSeasons = new System.Windows.Forms.TabPage();
            this.tpStages = new System.Windows.Forms.TabPage();
            this.tpGroups = new System.Windows.Forms.TabPage();
            this.tpEvent = new System.Windows.Forms.TabPage();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bnAreas = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tsbPrevious = new System.Windows.Forms.ToolStripButton();
            this.tsbNext = new System.Windows.Forms.ToolStripButton();
            this.nbAreasTotal = new System.Windows.Forms.ToolStripLabel();
            this.nbAreasPage = new System.Windows.Forms.ToolStripLabel();
            this.nbAreasCurrent = new System.Windows.Forms.ToolStripTextBox();
            this.tabControl1.SuspendLayout();
            this.tpAuthorization.SuspendLayout();
            this.gbAuthorization.SuspendLayout();
            this.tpAreas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAreas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnAreas)).BeginInit();
            this.bnAreas.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tpAuthorization);
            this.tabControl1.Controls.Add(this.tpAreas);
            this.tabControl1.Controls.Add(this.tpCompetitions);
            this.tabControl1.Controls.Add(this.tpSeasons);
            this.tabControl1.Controls.Add(this.tpStages);
            this.tabControl1.Controls.Add(this.tpGroups);
            this.tabControl1.Controls.Add(this.tpEvent);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(0, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(853, 560);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tpAuthorization
            // 
            this.tpAuthorization.Controls.Add(this.gbAuthorization);
            this.tpAuthorization.Location = new System.Drawing.Point(4, 29);
            this.tpAuthorization.Name = "tpAuthorization";
            this.tpAuthorization.Size = new System.Drawing.Size(845, 527);
            this.tpAuthorization.TabIndex = 5;
            this.tpAuthorization.Text = "Authorization";
            this.tpAuthorization.UseVisualStyleBackColor = true;
            // 
            // gbAuthorization
            // 
            this.gbAuthorization.Controls.Add(this.lbToken);
            this.gbAuthorization.Controls.Add(this.lbAuthorization);
            this.gbAuthorization.Location = new System.Drawing.Point(3, 17);
            this.gbAuthorization.Name = "gbAuthorization";
            this.gbAuthorization.Size = new System.Drawing.Size(505, 139);
            this.gbAuthorization.TabIndex = 0;
            this.gbAuthorization.TabStop = false;
            // 
            // lbToken
            // 
            this.lbToken.AutoSize = true;
            this.lbToken.Location = new System.Drawing.Point(26, 82);
            this.lbToken.Name = "lbToken";
            this.lbToken.Size = new System.Drawing.Size(0, 20);
            this.lbToken.TabIndex = 1;
            // 
            // lbAuthorization
            // 
            this.lbAuthorization.AutoSize = true;
            this.lbAuthorization.Location = new System.Drawing.Point(22, 32);
            this.lbAuthorization.Name = "lbAuthorization";
            this.lbAuthorization.Size = new System.Drawing.Size(0, 20);
            this.lbAuthorization.TabIndex = 0;
            // 
            // tpAreas
            // 
            this.tpAreas.Controls.Add(this.bnAreas);
            this.tpAreas.Controls.Add(this.dgvAreas);
            this.tpAreas.Location = new System.Drawing.Point(4, 29);
            this.tpAreas.Name = "tpAreas";
            this.tpAreas.Size = new System.Drawing.Size(845, 527);
            this.tpAreas.TabIndex = 0;
            this.tpAreas.Text = "areas";
            this.tpAreas.UseVisualStyleBackColor = true;
            // 
            // dgvAreas
            // 
            this.dgvAreas.AllowUserToOrderColumns = true;
            this.dgvAreas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAreas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAreas.Location = new System.Drawing.Point(0, 33);
            this.dgvAreas.Name = "dgvAreas";
            this.dgvAreas.Size = new System.Drawing.Size(845, 494);
            this.dgvAreas.TabIndex = 0;
            // 
            // tpCompetitions
            // 
            this.tpCompetitions.Location = new System.Drawing.Point(4, 29);
            this.tpCompetitions.Name = "tpCompetitions";
            this.tpCompetitions.Size = new System.Drawing.Size(845, 527);
            this.tpCompetitions.TabIndex = 0;
            this.tpCompetitions.Text = "competitions";
            this.tpCompetitions.UseVisualStyleBackColor = true;
            // 
            // tpSeasons
            // 
            this.tpSeasons.Location = new System.Drawing.Point(4, 29);
            this.tpSeasons.Name = "tpSeasons";
            this.tpSeasons.Padding = new System.Windows.Forms.Padding(3);
            this.tpSeasons.Size = new System.Drawing.Size(845, 527);
            this.tpSeasons.TabIndex = 1;
            this.tpSeasons.Text = "seasons";
            this.tpSeasons.UseVisualStyleBackColor = true;
            // 
            // tpStages
            // 
            this.tpStages.Location = new System.Drawing.Point(4, 29);
            this.tpStages.Name = "tpStages";
            this.tpStages.Padding = new System.Windows.Forms.Padding(3);
            this.tpStages.Size = new System.Drawing.Size(845, 527);
            this.tpStages.TabIndex = 2;
            this.tpStages.Text = "stages";
            this.tpStages.UseVisualStyleBackColor = true;
            // 
            // tpGroups
            // 
            this.tpGroups.Location = new System.Drawing.Point(4, 29);
            this.tpGroups.Name = "tpGroups";
            this.tpGroups.Padding = new System.Windows.Forms.Padding(3);
            this.tpGroups.Size = new System.Drawing.Size(845, 527);
            this.tpGroups.TabIndex = 3;
            this.tpGroups.Text = "groups";
            this.tpGroups.UseVisualStyleBackColor = true;
            // 
            // tpEvent
            // 
            this.tpEvent.Location = new System.Drawing.Point(4, 29);
            this.tpEvent.Name = "tpEvent";
            this.tpEvent.Padding = new System.Windows.Forms.Padding(3);
            this.tpEvent.Size = new System.Drawing.Size(845, 527);
            this.tpEvent.TabIndex = 4;
            this.tpEvent.Text = "event";
            this.tpEvent.UseVisualStyleBackColor = true;
            // 
            // bnAreas
            // 
            this.bnAreas.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bnAreas.CountItem = this.bindingNavigatorCountItem;
            this.bnAreas.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bnAreas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.tsbPrevious,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.nbAreasCurrent,
            this.bindingNavigatorPositionItem,
            this.nbAreasPage,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.tsbNext,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.nbAreasTotal});
            this.bnAreas.Location = new System.Drawing.Point(0, 0);
            this.bnAreas.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bnAreas.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bnAreas.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bnAreas.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bnAreas.Name = "bnAreas";
            this.bnAreas.PositionItem = this.bindingNavigatorPositionItem;
            this.bnAreas.Size = new System.Drawing.Size(845, 30);
            this.bnAreas.TabIndex = 1;
            this.bnAreas.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.bnAreas_ItemClicked);
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Visible = false;
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 30);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 30);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            this.bindingNavigatorPositionItem.Visible = false;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(49, 27);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            this.bindingNavigatorCountItem.Visible = false;
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 30);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Visible = false;
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 30);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // tsbPrevious
            // 
            this.tsbPrevious.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrevious.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrevious.Image")));
            this.tsbPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrevious.Name = "tsbPrevious";
            this.tsbPrevious.Size = new System.Drawing.Size(23, 27);
            this.tsbPrevious.Text = "Previous";
            // 
            // tsbNext
            // 
            this.tsbNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNext.Image = ((System.Drawing.Image)(resources.GetObject("tsbNext.Image")));
            this.tsbNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNext.Name = "tsbNext";
            this.tsbNext.Size = new System.Drawing.Size(23, 27);
            this.tsbNext.Text = "Next";
            // 
            // nbAreasTotal
            // 
            this.nbAreasTotal.Name = "nbAreasTotal";
            this.nbAreasTotal.Size = new System.Drawing.Size(0, 27);
            // 
            // nbAreasPage
            // 
            this.nbAreasPage.Name = "nbAreasPage";
            this.nbAreasPage.Size = new System.Drawing.Size(0, 27);
            // 
            // nbAreasCurrent
            // 
            this.nbAreasCurrent.AutoSize = false;
            this.nbAreasCurrent.Name = "nbAreasCurrent";
            this.nbAreasCurrent.Size = new System.Drawing.Size(50, 30);
            this.nbAreasCurrent.Text = "0";
            // 
            // DataOfScouts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 576);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DataOfScouts";
            this.Text = "D:\\Program Files (x86)\\Microsoft Visual Studio\\2017\\Professional\\Common7\\IDE\\Data" +
    "OfScouts";
            this.tabControl1.ResumeLayout(false);
            this.tpAuthorization.ResumeLayout(false);
            this.gbAuthorization.ResumeLayout(false);
            this.gbAuthorization.PerformLayout();
            this.tpAreas.ResumeLayout(false);
            this.tpAreas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAreas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnAreas)).EndInit();
            this.bnAreas.ResumeLayout(false);
            this.bnAreas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
 
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpAreas;
        private System.Windows.Forms.TabPage tpCompetitions;
        private System.Windows.Forms.TabPage tpSeasons;
        private System.Windows.Forms.TabPage tpStages;
        private System.Windows.Forms.TabPage tpGroups;
        private System.Windows.Forms.TabPage tpEvent;
        private System.Windows.Forms.DataGridView dgvAreas;
        private System.Windows.Forms.TabPage tpAuthorization;
        private System.Windows.Forms.GroupBox gbAuthorization;
        private System.Windows.Forms.Label lbAuthorization;
        private System.Windows.Forms.Label lbToken;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.BindingNavigator bnAreas;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tsbPrevious;
        private System.Windows.Forms.ToolStripTextBox nbAreasCurrent;
        private System.Windows.Forms.ToolStripLabel nbAreasPage;
        private System.Windows.Forms.ToolStripButton tsbNext;
        private System.Windows.Forms.ToolStripLabel nbAreasTotal;
    }
}

