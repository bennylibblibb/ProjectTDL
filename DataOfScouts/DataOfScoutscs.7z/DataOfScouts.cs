﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text;
using System.IO;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using FileLog;
using System.Net.Http.Headers;
using System.Data;
using FirebirdSql.Data.FirebirdClient;

namespace DataOfScouts
{
    public partial class DataOfScouts : Form
    {
        string strToken = "";
        OAuthClient clientTest = new OAuthClient();

        public DataOfScouts()
        {
            InitializeComponent();
            ClientAuthorize();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tpAreas)
            {
                var responseValue = clientTest.GetAccessData(strToken, "areas");
                var strResponseValue = responseValue.Result;
                DataSet ds = InsertData(0, strResponseValue, "areas");
                this.dgvAreas.DataSource = ds.Tables[0].DefaultView;

                dtbl = ds.Tables[0];

                BindingSource bs = new BindingSource();
                bs.DataSource = ds.Tables[0].DefaultView;
                bnAreas.BindingSource = bs;
                this.dgvAreas.DataSource = bs;

                total = ds.Tables[0].Rows.Count;
                pageCount = (total / AppFlag.iPageSize);
                if ((total % AppFlag.iPageSize > 0))
                {
                    pageCount++;
                }
                pageCurrent = 1;
                currentRow = 0;

                this.LoadData();
            }
        }

        int total = 0;
        int pageCount = 0;//总页数 
        int pageCurrent = 0;
        int currentRow = 0;//当前记录数从0开始 
        int nStartPos = 0;
        int nEndPos = 0;

        DataTable dtbl = null;
        private void LoadData()
        {
            int nStartPos = 0;
            int nEndPos = 0;
            DataTable dtTemp = dtbl.Clone();
            if (pageCurrent == pageCount)
            {
                nEndPos = total;
            }
            else
            {
                nEndPos = AppFlag.iPageSize * pageCurrent;
            }
            nStartPos = currentRow;

            nbAreasPage.Text = "of " + pageCount.ToString();
            // bindingNavigatorCountItem.Text = "of " + pageCount.ToString();
            if (dtbl.Rows.Count == 0)
            {
                nbAreasCurrent.Text = "0";
            }
            else
            {
                nbAreasCurrent.Text = Convert.ToString(pageCurrent);
            }
            this.nbAreasTotal.Text = total.ToString();

            if (dtbl.Rows.Count != 0)
            {
                for (int i = nStartPos; i < nEndPos; i++)
                {
                    dtTemp.ImportRow(dtbl.Rows[i]);
                    currentRow++;
                }

            }
            bindingSource1.DataSource = dtTemp;
            bnAreas.BindingSource = bindingSource1;
            dgvAreas.DataSource = bindingSource1;

        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            string str = "";
        }

        private void ClientAuthorize()
        {
            var responseValue = clientTest.GetAccessToken();
            var strResponseValue = responseValue.Result;
            var api = JObject.Parse(strResponseValue)["api"];
            var data = JObject.Parse(api.ToString())["data"];
            strToken = JObject.Parse(data.ToString())["token"].Value<string>();
            this.lbAuthorization.Text = "Authorized";
            this.lbToken.Text = strToken;
        }
        private DataSet InsertData(int iPage, string responsValue, string type)
        {
            string strName = type + "-" + iPage + " " + DateTime.Now.ToString("HHmmss");
            Files.WriteXml(strName, responsValue);

            string queryString = "select FIRST 1 * from " + type;
            DateTime cTimestamp = DateTime.Now;
            DataSet ds = new DataSet();
            int count = 0;

            switch (type)
            {
                case "areas":
                    {
                        DOSAreas.api apis = XmlUtil.Deserialize(typeof(DOSAreas.api), responsValue) as DOSAreas.api;
                        DOSAreas.apiDataAreasArea[] areas = apis.data[0];
                        using (FbConnection connection = new FbConnection(AppFlag.ScoutsDBConn))
                        {
                            FbDataAdapter adapter = new FbDataAdapter();
                            adapter.SelectCommand = new FbCommand(queryString, connection);
                            FbCommandBuilder builder = new FbCommandBuilder(adapter);
                            connection.Open();
                            DataSet areasDs = new DataSet();
                            adapter.Fill(areasDs);
                            if (areasDs.Tables[0].Rows.Count == 0)
                            {
                                //code to modify data in dataset here
                                foreach (DOSAreas.apiDataAreasArea area in areas)
                                {
                                    DataRow dr = areasDs.Tables[0].NewRow();
                                    dr[0] = area.id;
                                    dr[1] = area.area_code;
                                    dr[2] = area.name;
                                    dr[3] = area.parent_area_id;
                                    dr[4] = area.ut;
                                    dr[5] = cTimestamp;
                                    areasDs.Tables[0].Rows.Add(dr);
                                }

                                count = adapter.Update(areasDs);

                                //if (count > -1)
                                //{
                                //    Console.WriteLine("[Success] Insert areas [" + count + "/" + areas.Length + "]");
                                //    Files.WriteLog("[Success] Insert areas[" + count + " / " + areas.Length + "] " + strName + ".xml");
                                //}
                                //else
                                //{
                                //    Console.WriteLine("[Failure] Insert areas [" + areas.Length + "]");
                                //    Files.WriteLog("[Failure] Insert areas [" + areas.Length + "] " + strName + ".xml");
                                //}
                            }
                            else
                            {
                                count = -1;
                                areasDs.Clear();
                                queryString = "select   * from " + type;
                                adapter.SelectCommand = new FbCommand(queryString, connection);
                                adapter.Fill(areasDs);
                            }

                            ds = areasDs;
                            connection.Close();
                        }
                        break;
                    }
                case "competitions":
                    {
                        DOSCompetitions.api apis = XmlUtil.Deserialize(typeof(DOSCompetitions.api), responsValue) as DOSCompetitions.api;
                        DOSCompetitions.apiDataCompetitionsCompetition[] competitions = (apis.data.Length == 0) ? null : apis.data[0];
                        if (competitions == null) return null;
                        using (FbConnection connection = new FbConnection(AppFlag.ScoutsDBConn))
                        {
                            FbDataAdapter adapter = new FbDataAdapter();
                            adapter.SelectCommand = new FbCommand(queryString, connection);
                            FbCommandBuilder builder = new FbCommandBuilder(adapter);
                            connection.Open();
                            DataSet competitionDs = new DataSet();
                            adapter.Fill(competitionDs);
                            foreach (DOSCompetitions.apiDataCompetitionsCompetition competition in competitions)
                            {
                                DataRow dr = competitionDs.Tables[0].NewRow();
                                dr[0] = competition.id;
                                dr[1] = competition.name;
                                dr[2] = competition.short_name;
                                dr[3] = competition.mini_name;
                                dr[4] = (competition.gender.ToLower() == "male") ? true : false;
                                dr[5] = competition.type;
                                dr[6] = competition.area_id;
                                dr[7] = competition.area_name;
                                dr[8] = competition.area_type;
                                dr[9] = competition.area_sort;
                                dr[10] = competition.area_code;
                                dr[11] = competition.overall_sort;
                                dr[12] = competition.sport_id;
                                dr[13] = competition.sport_name;
                                dr[14] = (competition.tour_id == "") ? "-1" : competition.tour_id;
                                dr[15] = competition.tour_name;
                                dr[16] = competition.ut;
                                dr[17] = (competition.old_competition_id == "") ? "-1" : competition.old_competition_id;
                                dr[18] = competition.slug;
                                dr[19] = cTimestamp;
                                competitionDs.Tables[0].Rows.Add(dr);
                            }
                            count = adapter.Update(competitionDs);
                            connection.Close();
                            //if (count > -1)
                            //{
                            //    Console.WriteLine("[Success] Insert competitions [" + count + "/" + competitions.Length + "]");
                            //    Files.WriteLog("[Success] Insert competitions [" + competitions.Length + "] " + strName + ".xml");
                            //}
                            //else
                            //{
                            //    Console.WriteLine("[Failure] Insert competitions [" + competitions.Length + "]");
                            //    Files.WriteLog("[Failure] Insert competitions [" + competitions.Length + "] " + strName + ".xml");
                            //}
                            break;
                        }
                    }
                case "seasons":
                    {
                        DOSSeasons.api apis = XmlUtil.Deserialize(typeof(DOSSeasons.api), responsValue) as DOSSeasons.api;
                        DOSSeasons.apiDataCompetitionsCompetition[] competitions = (apis.data.Length == 0) ? null : apis.data[0];
                        if (competitions == null) return null;
                        using (FbConnection connection = new FbConnection(AppFlag.ScoutsDBConn))
                        {
                            FbDataAdapter adapter = new FbDataAdapter();
                            adapter.SelectCommand = new FbCommand(queryString, connection);
                            FbCommandBuilder builder = new FbCommandBuilder(adapter);
                            connection.Open();
                            DataSet seasonsDs = new DataSet();
                            adapter.Fill(seasonsDs);
                            //code to modify data in dataset here
                            foreach (DOSSeasons.apiDataCompetitionsCompetition competition in competitions)
                            {
                                string strCompetition_id = competition.id;
                                DOSSeasons.apiDataCompetitionSeason[] seasons = competition.seasons;
                                if (seasons == null) continue;
                                foreach (DOSSeasons.apiDataCompetitionSeason season in seasons)
                                {
                                    DataRow dr = seasonsDs.Tables[0].NewRow();
                                    dr[0] = season.id;
                                    dr[1] = season.name;
                                    dr[2] = strCompetition_id;
                                    dr[3] = season.year;
                                    dr[4] = season.actual;
                                    dr[5] = season.ut;
                                    dr[6] = (season.old_season_id == "") ? "-1" : season.old_season_id;
                                    dr[7] = season.range;
                                    dr[8] = cTimestamp;
                                    seasonsDs.Tables[0].Rows.Add(dr);
                                }
                            }
                            count = adapter.Update(seasonsDs);
                            connection.Close();

                            //if (count > -1)
                            //{
                            //    Console.WriteLine("[Success] Insert seasons [" + count + " " + "]");
                            //    Files.WriteLog("[Success] Insert seasons[" + count + "  " + "] " + " " + strName + ".xml");
                            //}
                            //else
                            //{
                            //    Console.WriteLine("[Failure] Insert seasons [  ]");
                            //    Files.WriteLog("[Failure] Insert seasons [  ]" + " " + strName + ".xml");
                            //}
                        }
                        break;
                    }
                default:
                    break;
            }
            if (count > -1)
            {
                Files.WriteLog("[Success] Insert " + type + " [" + count + "] " + strName + ".xml");
            }
            else
            {
                Files.WriteLog("[Failure] Insert " + type + " [" + count + "] " + strName + ".xml");
            }
            return ds;
        }

        private void bnAreas_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem.Text == "Previous")
            {
                if (pageCurrent >= 0)
                {
                    pageCurrent--;
                }
                if (pageCurrent <= 0)
                {
                    pageCurrent++;
                    // MessageBox.Show("已经是第一页");
                    return;
                }
                else
                {
                    currentRow = AppFlag.iPageSize * (pageCurrent - 1);
                }
                //
                LoadData();
                // 
            }

            if (e.ClickedItem.Text == "Next")
            {
                if (pageCurrent <= pageCount)
                {
                    pageCurrent++;
                }
                if (pageCurrent > pageCount)
                {
                    pageCurrent--;
                    // MessageBox.Show("已经是最后一页");
                    return;
                }
                else
                {
                    currentRow = AppFlag.iPageSize * (pageCurrent - 1);
                }
                //
                nStartPos = 0;
                nEndPos = 0;
                DataTable dtTemp = dtbl.Clone();
                if (pageCurrent == pageCount)
                {
                    nEndPos = total;
                }
                else
                {
                    nEndPos = AppFlag.iPageSize * pageCurrent;
                }
                nStartPos = currentRow;

                nbAreasPage.Text = "of " + pageCount.ToString();
                //bindingNavigatorCountItem.Text =  "of " + pageCount.ToString();
                if (dtbl.Rows.Count == 0)
                {
                    nbAreasCurrent.Text = "0";
                }
                else
                {
                    nbAreasCurrent.Text = Convert.ToString(pageCurrent);
                }
                this.nbAreasTotal.Text = total.ToString();

                if (dtbl.Rows.Count != 0)
                {
                    for (int i = nStartPos; i < nEndPos; i++)
                    {
                        dtTemp.ImportRow(dtbl.Rows[i]);
                        currentRow++;
                    }
                }
                bindingSource1.DataSource = dtTemp;
                bnAreas.BindingSource = bindingSource1;
                this.dgvAreas.DataSource = bindingSource1;

            }
        }
    }

    class OAuthClient
    {
        private HttpClient _httpClient;
       // private string token;

        public OAuthClient()
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri(AppFlag .ScoutsUrl);
        }

        public async Task<string> GetAccessToken()
        {
            var client_id = AppFlag .Client_id;
            var secret_key = AppFlag .Secret_key ;
            var response = await _httpClient.GetAsync($"/v2/oauth?client_id={client_id}&secret_key={secret_key}").ConfigureAwait(false);
            var responseValue = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            { return responseValue;
            }
            else
            {
                return string.Empty;
            }
        }

        public async Task<string> GetAccessData(string token, string type)
        {
            string strUrl = "";
            if (type.IndexOf("areas") > -1)
            {
                strUrl = $"/v2/" + ((type.IndexOf("/") > -1) ? "areas.xml?parent_area_id=" + type.Substring(type.IndexOf("/") + 1, type.Length - type.IndexOf("/") - 1) : type + ".xml");
                Console.WriteLine("GET areas " + strUrl);
                Files.WriteLog("GET areas " + strUrl);
            }
            else if (type.IndexOf("competitions") > -1)
            {
                strUrl = $"/v2/competitions.xml?token=" + token + "&sport_id=5&page=" + type.Substring(type.IndexOf("/") + 1, type.Length - type.IndexOf("/") - 1);

                Console.WriteLine("GET competitions " + strUrl);
                Files.WriteLog("GET competitions " + strUrl);
            }
            else if (type.IndexOf("seasons") > -1)
            {
                strUrl = $"/v2/seasons.xml?token=" + token + "&sport_id=5&page=" + type.Substring(type.IndexOf("/") + 1, type.Length - type.IndexOf("/") - 1);
                Console.WriteLine("GET seasons " + strUrl);
                Files.WriteLog("GET seasons " + strUrl);
            }
            var response = await _httpClient.GetAsync(strUrl).ConfigureAwait(false);
            var responseValue = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return responseValue;
            }
            else
            {
                Console.WriteLine("Empty: " + responseValue);
                return string.Empty;
            }



            //switch (type.Substring(0, 5))
            //{
            //    case "areas":
            //        strUrl = $"/v2/" + type + ".xml?parent_area_id=209";
            //        break;
            //    default:
            //        break;
            //}

        }

        //public async Task Call_WebAPI_By_Resource_Owner_Password_Credentials_Grant()
        //{
        //    var client_id = "262";
        //    var secret_key = "ksUzQEuI5neLBOEgX6ZdqisPfC5Lv91u2TE";
        //    if (string.IsNullOrEmpty(token))
        //        token = await GetAccessToken();
        //    Console.WriteLine(token);
        //    _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        //    Console.WriteLine(await (await _httpClient.GetAsync($"/v2/oauth?client_id={client_id}&secret_key={secret_key}")).Content.ReadAsStringAsync());
        //}

        //public async Task<string> Call_WebAPIByType(string token, string type)
        //{
        //    switch (type)
        //    {
        //        case "areas":
        //            //https://api.statscore.com/v2/areas.xml
        //            //https://api.statscore.com/v2/areas.xml?parent_area_id=209
        //            var returns = (await (await _httpClient.GetAsync($"/v2/areas.xml?parent_area_id=209")).Content.ReadAsStringAsync());
        //            Console.WriteLine(returns);

        //            Console.WriteLine("-----------------------------areas----------------------------");

        //            break;
        //        default:
        //            break;
        //    }
        //    return "";
        //}

    }
}
