﻿using System.IO;

namespace DataOfScouts
{
    partial class DataOfScouts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        { 
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataOfScouts));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpAuthorization = new System.Windows.Forms.TabPage();
            this.gbAuthorization = new System.Windows.Forms.GroupBox();
            this.lbToken = new System.Windows.Forms.Label();
            this.lbAuthorization = new System.Windows.Forms.Label();
            this.tpAreas = new System.Windows.Forms.TabPage();
            this.dgvAreas = new System.Windows.Forms.DataGridView();
            this.tpCompetitions = new System.Windows.Forms.TabPage();
            this.dgvComp = new System.Windows.Forms.DataGridView();
            this.tpSeasons = new System.Windows.Forms.TabPage();
            this.dgvSeasons = new System.Windows.Forms.DataGridView();
            this.tpStages = new System.Windows.Forms.TabPage();
            this.tpGroups = new System.Windows.Forms.TabPage();
            this.tpParticipants = new System.Windows.Forms.TabPage();
            this.dgvPart = new System.Windows.Forms.DataGridView();
            this.tpEvent = new System.Windows.Forms.TabPage();
            this.dgvEvent = new System.Windows.Forms.DataGridView();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.bnAreas = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.tsbPrevious = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.nbAreasCurrent = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.nbAreasPage = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbNext = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.nbAreasTotal = new System.Windows.Forms.ToolStripLabel();
            this.tsbArea = new System.Windows.Forms.ToolStripTextBox();
            this.tsdArea = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsdComp = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsdSeason = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsdStage = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsdGroup = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsbPartic = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsdEvent = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripDropDownButton4 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripDropDownButton5 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripDropDownButton6 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripDropDownButton7 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.tabControl1.SuspendLayout();
            this.tpAuthorization.SuspendLayout();
            this.gbAuthorization.SuspendLayout();
            this.tpAreas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAreas)).BeginInit();
            this.tpCompetitions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComp)).BeginInit();
            this.tpSeasons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeasons)).BeginInit();
            this.tpParticipants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPart)).BeginInit();
            this.tpEvent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnAreas)).BeginInit();
            this.bnAreas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tpAuthorization);
            this.tabControl1.Controls.Add(this.tpAreas);
            this.tabControl1.Controls.Add(this.tpCompetitions);
            this.tabControl1.Controls.Add(this.tpSeasons);
            this.tabControl1.Controls.Add(this.tpStages);
            this.tabControl1.Controls.Add(this.tpGroups);
            this.tabControl1.Controls.Add(this.tpParticipants);
            this.tabControl1.Controls.Add(this.tpEvent);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl1.Location = new System.Drawing.Point(0, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(853, 509);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tpAuthorization
            // 
            this.tpAuthorization.Controls.Add(this.gbAuthorization);
            this.tpAuthorization.Location = new System.Drawing.Point(4, 29);
            this.tpAuthorization.Name = "tpAuthorization";
            this.tpAuthorization.Size = new System.Drawing.Size(845, 476);
            this.tpAuthorization.TabIndex = 5;
            this.tpAuthorization.Text = "Authorization";
            this.tpAuthorization.UseVisualStyleBackColor = true;
            // 
            // gbAuthorization
            // 
            this.gbAuthorization.Controls.Add(this.lbToken);
            this.gbAuthorization.Controls.Add(this.lbAuthorization);
            this.gbAuthorization.Location = new System.Drawing.Point(3, 17);
            this.gbAuthorization.Name = "gbAuthorization";
            this.gbAuthorization.Size = new System.Drawing.Size(505, 139);
            this.gbAuthorization.TabIndex = 0;
            this.gbAuthorization.TabStop = false;
            // 
            // lbToken
            // 
            this.lbToken.AutoSize = true;
            this.lbToken.Location = new System.Drawing.Point(26, 82);
            this.lbToken.Name = "lbToken";
            this.lbToken.Size = new System.Drawing.Size(0, 20);
            this.lbToken.TabIndex = 1;
            // 
            // lbAuthorization
            // 
            this.lbAuthorization.AutoSize = true;
            this.lbAuthorization.Location = new System.Drawing.Point(22, 32);
            this.lbAuthorization.Name = "lbAuthorization";
            this.lbAuthorization.Size = new System.Drawing.Size(0, 20);
            this.lbAuthorization.TabIndex = 0;
            // 
            // tpAreas
            // 
            this.tpAreas.Controls.Add(this.dgvAreas);
            this.tpAreas.Location = new System.Drawing.Point(4, 29);
            this.tpAreas.Name = "tpAreas";
            this.tpAreas.Size = new System.Drawing.Size(845, 476);
            this.tpAreas.TabIndex = 0;
            this.tpAreas.Text = "areas";
            this.tpAreas.UseVisualStyleBackColor = true;
            // 
            // dgvAreas
            // 
            this.dgvAreas.AllowUserToOrderColumns = true;
            this.dgvAreas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAreas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvAreas.Location = new System.Drawing.Point(3, 3);
            this.dgvAreas.Name = "dgvAreas";
            this.dgvAreas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
            this.dgvAreas.Size = new System.Drawing.Size(839, 490);
            this.dgvAreas.TabIndex = 0;
            // 
            // tpCompetitions
            // 
            this.tpCompetitions.Controls.Add(this.dgvComp);
            this.tpCompetitions.Location = new System.Drawing.Point(4, 29);
            this.tpCompetitions.Name = "tpCompetitions";
            this.tpCompetitions.Size = new System.Drawing.Size(845, 476);
            this.tpCompetitions.TabIndex = 0;
            this.tpCompetitions.Text = "competitions";
            this.tpCompetitions.UseVisualStyleBackColor = true;
            // 
            // dgvComp
            // 
            this.dgvComp.AllowUserToOrderColumns = true;
            this.dgvComp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvComp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvComp.Location = new System.Drawing.Point(3, 3);
            this.dgvComp.Name = "dgvComp";
            this.dgvComp.Size = new System.Drawing.Size(839, 490);
            this.dgvComp.TabIndex = 1;
            // 
            // tpSeasons
            // 
            this.tpSeasons.Controls.Add(this.dgvSeasons);
            this.tpSeasons.Location = new System.Drawing.Point(4, 29);
            this.tpSeasons.Name = "tpSeasons";
            this.tpSeasons.Padding = new System.Windows.Forms.Padding(3);
            this.tpSeasons.Size = new System.Drawing.Size(845, 476);
            this.tpSeasons.TabIndex = 1;
            this.tpSeasons.Text = "seasons";
            this.tpSeasons.UseVisualStyleBackColor = true;
            // 
            // dgvSeasons
            // 
            this.dgvSeasons.AllowUserToOrderColumns = true;
            this.dgvSeasons.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSeasons.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSeasons.Location = new System.Drawing.Point(3, 3);
            this.dgvSeasons.Name = "dgvSeasons";
            this.dgvSeasons.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
            this.dgvSeasons.Size = new System.Drawing.Size(839, 490);
            this.dgvSeasons.TabIndex = 1;
            // 
            // tpStages
            // 
            this.tpStages.Location = new System.Drawing.Point(4, 29);
            this.tpStages.Name = "tpStages";
            this.tpStages.Padding = new System.Windows.Forms.Padding(3);
            this.tpStages.Size = new System.Drawing.Size(845, 476);
            this.tpStages.TabIndex = 2;
            this.tpStages.Text = "stages";
            this.tpStages.UseVisualStyleBackColor = true;
            // 
            // tpGroups
            // 
            this.tpGroups.Location = new System.Drawing.Point(4, 29);
            this.tpGroups.Name = "tpGroups";
            this.tpGroups.Padding = new System.Windows.Forms.Padding(3);
            this.tpGroups.Size = new System.Drawing.Size(845, 476);
            this.tpGroups.TabIndex = 3;
            this.tpGroups.Text = "groups";
            this.tpGroups.UseVisualStyleBackColor = true;
            // 
            // tpParticipants
            // 
            this.tpParticipants.Controls.Add(this.dgvPart);
            this.tpParticipants.Location = new System.Drawing.Point(4, 29);
            this.tpParticipants.Name = "tpParticipants";
            this.tpParticipants.Size = new System.Drawing.Size(845, 476);
            this.tpParticipants.TabIndex = 6;
            this.tpParticipants.Text = "participants";
            this.tpParticipants.UseVisualStyleBackColor = true;
            // 
            // dgvPart
            // 
            this.dgvPart.AllowUserToOrderColumns = true;
            this.dgvPart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPart.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPart.Location = new System.Drawing.Point(3, 3);
            this.dgvPart.Name = "dgvPart";
            this.dgvPart.Size = new System.Drawing.Size(839, 490);
            this.dgvPart.TabIndex = 3;
            // 
            // tpEvent
            // 
            this.tpEvent.Controls.Add(this.dgvEvent);
            this.tpEvent.Location = new System.Drawing.Point(4, 29);
            this.tpEvent.Name = "tpEvent";
            this.tpEvent.Padding = new System.Windows.Forms.Padding(3);
            this.tpEvent.Size = new System.Drawing.Size(845, 476);
            this.tpEvent.TabIndex = 4;
            this.tpEvent.Text = "events";
            this.tpEvent.UseVisualStyleBackColor = true;
            // 
            // dgvEvent
            // 
            this.dgvEvent.AllowUserToOrderColumns = true;
            this.dgvEvent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEvent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvEvent.Location = new System.Drawing.Point(3, 3);
            this.dgvEvent.Name = "dgvEvent";
            this.dgvEvent.Size = new System.Drawing.Size(839, 490);
            this.dgvEvent.TabIndex = 2;
            // 
            // bnAreas
            // 
            this.bnAreas.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bnAreas.CountItem = this.bindingNavigatorCountItem;
            this.bnAreas.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bnAreas.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bnAreas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.tsbPrevious,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.nbAreasCurrent,
            this.bindingNavigatorPositionItem,
            this.nbAreasPage,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.tsbNext,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.nbAreasTotal,
            this.tsbArea,
            this.tsdArea,
            this.tsdComp,
            this.tsdSeason,
            this.tsdStage,
            this.tsdGroup,
            this.tsbPartic,
            this.tsdEvent,
            this.toolStripButton1});
            this.bnAreas.Location = new System.Drawing.Point(0, 546);
            this.bnAreas.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bnAreas.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bnAreas.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bnAreas.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bnAreas.Name = "bnAreas";
            this.bnAreas.PositionItem = this.bindingNavigatorPositionItem;
            this.bnAreas.Size = new System.Drawing.Size(865, 30);
            this.bnAreas.TabIndex = 2;
            this.bnAreas.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.bnAreas_ItemClicked);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(49, 27);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            this.bindingNavigatorCountItem.Visible = false;
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // tsbPrevious
            // 
            this.tsbPrevious.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPrevious.Image = ((System.Drawing.Image)(resources.GetObject("tsbPrevious.Image")));
            this.tsbPrevious.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPrevious.Name = "tsbPrevious";
            this.tsbPrevious.Size = new System.Drawing.Size(23, 27);
            this.tsbPrevious.Text = "Previous";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Visible = false;
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 30);
            // 
            // nbAreasCurrent
            // 
            this.nbAreasCurrent.AutoSize = false;
            this.nbAreasCurrent.Name = "nbAreasCurrent";
            this.nbAreasCurrent.Size = new System.Drawing.Size(50, 30);
            this.nbAreasCurrent.Text = "0";
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(2, 30);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            this.bindingNavigatorPositionItem.Visible = false;
            // 
            // nbAreasPage
            // 
            this.nbAreasPage.Name = "nbAreasPage";
            this.nbAreasPage.Size = new System.Drawing.Size(0, 27);
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 30);
            // 
            // tsbNext
            // 
            this.tsbNext.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNext.Image = ((System.Drawing.Image)(resources.GetObject("tsbNext.Image")));
            this.tsbNext.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNext.Name = "tsbNext";
            this.tsbNext.Size = new System.Drawing.Size(23, 27);
            this.tsbNext.Text = "Next";
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Visible = false;
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 27);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 30);
            // 
            // nbAreasTotal
            // 
            this.nbAreasTotal.Name = "nbAreasTotal";
            this.nbAreasTotal.Size = new System.Drawing.Size(0, 27);
            // 
            // tsbArea
            // 
            this.tsbArea.Name = "tsbArea";
            this.tsbArea.Size = new System.Drawing.Size(50, 30);
            // 
            // tsdArea
            // 
            this.tsdArea.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsdArea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tsdArea.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdArea.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.tsdArea.Image = ((System.Drawing.Image)(resources.GetObject("tsdArea.Image")));
            this.tsdArea.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdArea.Name = "tsdArea";
            this.tsdArea.Size = new System.Drawing.Size(56, 27);
            this.tsdArea.Text = "area";
            this.tsdArea.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsdArea_DropDownItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(224, 28);
            this.toolStripMenuItem1.Text = "aaaaaaaaaaaaaaaa";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(224, 28);
            this.toolStripMenuItem2.Text = "bbbbbbbbbbbbb";
            // 
            // tsdComp
            // 
            this.tsdComp.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsdComp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdComp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.tsdComp.Image = ((System.Drawing.Image)(resources.GetObject("tsdComp.Image")));
            this.tsdComp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdComp.Name = "tsdComp";
            this.tsdComp.Size = new System.Drawing.Size(115, 27);
            this.tsdComp.Text = "competition";
            this.tsdComp.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tsdComp_DropDownItemClicked);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(216, 28);
            this.toolStripMenuItem3.Text = "xxxxxxxxxxxxx";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(216, 28);
            this.toolStripMenuItem4.Text = "ccccccccccccccccc";
            // 
            // tsdSeason
            // 
            this.tsdSeason.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsdSeason.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdSeason.Image = ((System.Drawing.Image)(resources.GetObject("tsdSeason.Image")));
            this.tsdSeason.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdSeason.Name = "tsdSeason";
            this.tsdSeason.Size = new System.Drawing.Size(75, 27);
            this.tsdSeason.Text = "season";
            // 
            // tsdStage
            // 
            this.tsdStage.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsdStage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdStage.Image = ((System.Drawing.Image)(resources.GetObject("tsdStage.Image")));
            this.tsdStage.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdStage.Name = "tsdStage";
            this.tsdStage.Size = new System.Drawing.Size(66, 27);
            this.tsdStage.Text = "Stage";
            // 
            // tsdGroup
            // 
            this.tsdGroup.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsdGroup.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdGroup.Image = ((System.Drawing.Image)(resources.GetObject("tsdGroup.Image")));
            this.tsdGroup.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdGroup.Name = "tsdGroup";
            this.tsdGroup.Size = new System.Drawing.Size(69, 27);
            this.tsdGroup.Text = "group";
            // 
            // tsbPartic
            // 
            this.tsbPartic.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsbPartic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPartic.Image = ((System.Drawing.Image)(resources.GetObject("tsbPartic.Image")));
            this.tsbPartic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPartic.Name = "tsbPartic";
            this.tsbPartic.Size = new System.Drawing.Size(105, 27);
            this.tsbPartic.Text = "participant";
            // 
            // tsdEvent
            // 
            this.tsdEvent.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tsdEvent.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsdEvent.Image = ((System.Drawing.Image)(resources.GetObject("tsdEvent.Image")));
            this.tsdEvent.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsdEvent.Name = "tsdEvent";
            this.tsdEvent.Size = new System.Drawing.Size(65, 27);
            this.tsdEvent.Text = "event";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(41, 27);
            this.toolStripButton1.Text = "Get";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 30);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "Position";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(2, 30);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "Current position";
            this.toolStripTextBox2.Visible = false;
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(0, 27);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(0, 27);
            // 
            // toolStripTextBox3
            // 
            this.toolStripTextBox3.Name = "toolStripTextBox3";
            this.toolStripTextBox3.Size = new System.Drawing.Size(50, 30);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(56, 27);
            this.toolStripDropDownButton1.Text = "area";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(224, 28);
            this.toolStripMenuItem5.Text = "aaaaaaaaaaaaaaaa";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(224, 28);
            this.toolStripMenuItem6.Text = "bbbbbbbbbbbbb";
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(115, 27);
            this.toolStripDropDownButton2.Text = "competition";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(216, 28);
            this.toolStripMenuItem7.Text = "xxxxxxxxxxxxx";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(216, 28);
            this.toolStripMenuItem8.Text = "ccccccccccccccccc";
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton3.Image")));
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(75, 27);
            this.toolStripDropDownButton3.Text = "season";
            // 
            // toolStripDropDownButton4
            // 
            this.toolStripDropDownButton4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton4.Image")));
            this.toolStripDropDownButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton4.Name = "toolStripDropDownButton4";
            this.toolStripDropDownButton4.Size = new System.Drawing.Size(66, 27);
            this.toolStripDropDownButton4.Text = "Stage";
            // 
            // toolStripDropDownButton5
            // 
            this.toolStripDropDownButton5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton5.Image")));
            this.toolStripDropDownButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton5.Name = "toolStripDropDownButton5";
            this.toolStripDropDownButton5.Size = new System.Drawing.Size(69, 27);
            this.toolStripDropDownButton5.Text = "group";
            // 
            // toolStripDropDownButton6
            // 
            this.toolStripDropDownButton6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton6.Image")));
            this.toolStripDropDownButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton6.Name = "toolStripDropDownButton6";
            this.toolStripDropDownButton6.Size = new System.Drawing.Size(105, 27);
            this.toolStripDropDownButton6.Text = "participant";
            // 
            // toolStripDropDownButton7
            // 
            this.toolStripDropDownButton7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.toolStripDropDownButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton7.Image")));
            this.toolStripDropDownButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton7.Name = "toolStripDropDownButton7";
            this.toolStripDropDownButton7.Size = new System.Drawing.Size(65, 27);
            this.toolStripDropDownButton7.Text = "event";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(41, 27);
            this.toolStripButton10.Text = "Get";
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.CountItem = null;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.toolStripTextBox2,
            this.toolStripLabel2,
            this.toolStripLabel3,
            this.toolStripTextBox3,
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton2,
            this.toolStripDropDownButton3,
            this.toolStripDropDownButton4,
            this.toolStripDropDownButton5,
            this.toolStripDropDownButton6,
            this.toolStripDropDownButton7,
            this.toolStripButton10});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 516);
            this.bindingNavigator1.MoveFirstItem = null;
            this.bindingNavigator1.MoveLastItem = null;
            this.bindingNavigator1.MoveNextItem = null;
            this.bindingNavigator1.MovePreviousItem = null;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.toolStripTextBox2;
            this.bindingNavigator1.Size = new System.Drawing.Size(865, 30);
            this.bindingNavigator1.TabIndex = 3;
            // 
            // DataOfScouts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 576);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.bnAreas);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DataOfScouts";
            this.Text = "D:\\Program Files (x86)\\Microsoft Visual Studio\\2017\\Professional\\Common7\\IDE\\Data" +
    "OfScouts";
            this.tabControl1.ResumeLayout(false);
            this.tpAuthorization.ResumeLayout(false);
            this.gbAuthorization.ResumeLayout(false);
            this.gbAuthorization.PerformLayout();
            this.tpAreas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAreas)).EndInit();
            this.tpCompetitions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvComp)).EndInit();
            this.tpSeasons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeasons)).EndInit();
            this.tpParticipants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPart)).EndInit();
            this.tpEvent.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bnAreas)).EndInit();
            this.bnAreas.ResumeLayout(false);
            this.bnAreas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
 
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpAreas;
        private System.Windows.Forms.TabPage tpCompetitions;
        private System.Windows.Forms.TabPage tpSeasons;
        private System.Windows.Forms.TabPage tpStages;
        private System.Windows.Forms.TabPage tpGroups;
        private System.Windows.Forms.TabPage tpEvent;
        private System.Windows.Forms.DataGridView dgvAreas;
        private System.Windows.Forms.TabPage tpAuthorization;
        private System.Windows.Forms.GroupBox gbAuthorization;
        private System.Windows.Forms.Label lbAuthorization;
        private System.Windows.Forms.Label lbToken;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.BindingNavigator bnAreas;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton tsbPrevious;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox nbAreasCurrent;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripLabel nbAreasPage;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton tsbNext;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripLabel nbAreasTotal;
        private System.Windows.Forms.DataGridView dgvComp;
        private System.Windows.Forms.DataGridView dgvSeasons;
        private System.Windows.Forms.DataGridView dgvEvent;
        private System.Windows.Forms.TabPage tpParticipants;
        private System.Windows.Forms.DataGridView dgvPart;
        private System.Windows.Forms.ToolStripTextBox tsbArea;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripDropDownButton tsdArea;
        private System.Windows.Forms.ToolStripDropDownButton tsdComp;
        private System.Windows.Forms.ToolStripDropDownButton tsdSeason;
        private System.Windows.Forms.ToolStripDropDownButton tsdStage;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripDropDownButton tsdGroup;
        private System.Windows.Forms.ToolStripDropDownButton tsbPartic;
        private System.Windows.Forms.ToolStripDropDownButton tsdEvent;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton4;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton5;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton6;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
    }
}

